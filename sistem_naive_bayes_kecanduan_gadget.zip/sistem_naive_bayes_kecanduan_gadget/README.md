# Penyimpanan otomatis lokal

Versi ini memakai SQLite yang sudah termasuk dalam Python. **Tidak perlu membuat akun Supabase, mengisi secrets, atau menyalakan XAMPP/MySQL.** Setelah siswa mengirim kuesioner, jawaban disimpan otomatis ke `data/jawaban_siswa.db` dan dapat dibaca oleh halaman Guru/Admin pada komputer yang menjalankan aplikasi ini. Jangan hapus file database tersebut jika ingin mempertahankan data. Untuk menjalankan aplikasi di komputer berbeda atau secara online, diperlukan mekanisme database/server bersama.

## Menjalankan aplikasi
1. Ekstrak ZIP.
2. Buka terminal pada folder yang berisi `app.py`.
3. Jalankan `python -m pip install -r requirements.txt`.
4. Jalankan `python -m streamlit run app.py`.

---

# Sistem Analisis Tingkat Kecanduan Gadget pada Siswa SMP (Naive Bayes)

Sistem klasifikasi tingkat kecanduan gadget siswa SMP (kelas VII, VIII, IX) berdasarkan
**Instrumen Penelitian Kecanduan Gadget** (15 pernyataan). Klasifikasi memakai algoritma
**Gaussian Naive Bayes** yang diimplementasikan secara manual (from scratch, tanpa
`fit()`/`predict()` siap pakai dari scikit-learn). Antarmuka web dibangun dengan Streamlit
dan menggunakan tampilan formal (palet biru tua dan abu-abu, tanpa ikon atau emoji).

## Pilihan Jawaban Kuesioner

Siswa menjawab setiap pernyataan dengan memilih satu huruf yang disertai keterangannya
(misalnya "D. Setuju"). Huruf dikonversi menjadi skor
saat perhitungan, sehingga Total Skor tetap berada pada rentang 15 sampai 75.

| Pilihan | Keterangan | Skor |
|:-:|---|:-:|
| A | Sangat Tidak Setuju (STS) | 1 |
| B | Tidak Setuju (TS) | 2 |
| C | Netral (N) | 3 |
| D | Setuju (S) | 4 |
| E | Sangat Setuju (SS) | 5 |

Data yang tersimpan di database dan dataset Excel tetap berupa angka 1 sampai 5 pada kolom
P1 sampai P15. Konversi huruf ke angka dapat diubah pada konstanta `SKOR_JAWABAN` di `app.py`.

## Dua Peran Pengguna

Saat sistem dibuka, pengguna memilih salah satu peran berikut:

- **Siswa**: langsung diarahkan ke form kuesioner (15 pernyataan). Tidak memerlukan login.
  Setelah jawaban dikirim, hasil klasifikasi tingkat kecanduan ditampilkan apabila model
  sudah dilatih oleh Admin.
- **Guru / Administrator**: memasukkan **kata sandi** (konstanta `ADMIN_PASSWORD` di bagian
  atas `app.py`, bawaan: `admin123`, **wajib diganti** sebelum dipakai sungguhan) untuk
  membuka panel pengelolaan data dan analisis (5 menu: Dashboard, Data, Training & Model,
  Klasifikasi & Evaluasi, Laporan / Hasil Akhir).

## Penyimpanan Jawaban Secara Lokal

Tanpa database, jawaban siswa hanya tersimpan sementara di sesi browser dan hilang saat
aplikasi ditutup atau dijalankan ulang. Dengan Supabase (PostgreSQL gratis), jawaban setiap
siswa tersimpan permanen dan dapat dimuat kembali oleh admin kapan saja.

### Langkah setup (sekali saja)

1. Daftar gratis di [supabase.com](https://supabase.com), lalu buat **New Project**
   (catat kata sandi database; tidak dipakai aplikasi, tetapi diminta saat pembuatan).
2. Buka **SQL Editor** > **New query**, tempel seluruh isi file **`supabase_setup.sql`**
   (ada di folder proyek), lalu klik **Run**. Ini membuat tabel `jawaban_kuesioner`.
3. Buka **Project Settings** > **API**, lalu salin dua nilai:
   - **Project URL** (bentuknya `https://xxxx.supabase.co`)
   - **anon public key** (atau *publishable key* pada tampilan Supabase yang lebih baru)
4. Salin file `.streamlit/secrets.toml.example` menjadi **`.streamlit/secrets.toml`**,
   lalu isi dengan dua nilai tersebut:
   ```toml
   SUPABASE_URL = "https://xxxxxxxxxxxx.supabase.co"
   SUPABASE_KEY = "isi-dengan-anon-public-key"
   ```
   File `secrets.toml` sudah masuk `.gitignore`, jadi tidak ikut terunggah ke GitHub.
   Jika aplikasi didepoy di Streamlit Community Cloud, isi yang sama ditempel pada
   **Settings** > **Secrets**.
5. Jalankan ulang aplikasi (`Ctrl+C`, lalu `streamlit run app.py`). Pada form kuesioner akan
   muncul keterangan **Database terhubung**.

Jika masih muncul **Database belum terhubung**, keterangan di bawahnya menjelaskan penyebabnya
(secrets belum diisi, kunci salah, atau tabel belum dibuat). Perubahan pada `secrets.toml`
memerlukan aplikasi dijalankan ulang.

### Alur data

- Siswa mengisi kuesioner di Kuesioner Siswa, lalu jawaban langsung tersimpan ke Supabase.
- Admin membuka **Data** > **Data Siswa** dan menekan **Muat dari Database** untuk menarik
  seluruh jawaban ke dalam sistem. Jawaban yang belum punya label tingkat kecanduan diberi
  label berdasarkan Total Skor dengan batas tetap: Rendah 15 sampai 35, Sedang 36 sampai 55,
  Tinggi 56 sampai 75.
- Dataset Excel yang diunggah admin (struktur kolom P1 sampai P15) dapat disimpan ke database
  yang sama melalui kotak centang pada tab **Upload Dataset**. Hindari mengunggah file yang
  sama dua kali dengan opsi ini aktif, karena baris akan tersimpan ganda.
- Hasil klasifikasi siswa tidak disimpan sebagai label permanen. Label dihitung ulang dari
  skor saat data dimuat, sehingga prediksi lama tidak ikut menjadi data latih.

## Struktur Proyek

```
sistem_naive_bayes_kecanduan_gadget/
├── app.py                  # Seluruh tampilan/halaman (Dashboard sampai Laporan)
├── core.py                 # Seluruh logika (tema, pembaca Excel, preprocessing,
│                           #   algoritma Naive Bayes manual, pipeline, laporan)
├── database.py             # Koneksi dan operasi database Supabase
├── supabase_setup.sql      # Skrip pembuatan tabel (dijalankan sekali di Supabase)
├── requirements.txt        # Daftar library yang dibutuhkan
├── .streamlit/
│   ├── config.toml         # Warna dasar tema formal
│   └── secrets.toml.example # Contoh isi kunci Supabase
├── data/
│   └── contoh_dataset.xlsx # Contoh dataset untuk diunduh/diuji
└── README.md
```

Menu di sidebar panel admin:

1. **Dashboard**: ringkasan progres, grafik distribusi, aktivitas terakhir.
2. **Data** (3 tab):
   - *Upload Dataset*: pembacaan Excel (deteksi header, penggabungan sheet per kelas,
     pembuatan label Rendah/Sedang/Tinggi dari Total Skor) dan opsi menjalankan seluruh analisis.
   - *Data Siswa*: pencarian, filter, dan statistik deskriptif.
   - *Preprocessing Data*: penanganan missing value dan duplikat, pemilihan kolom target
     dan fitur (kolom skor/rekap seperti "Total Skor" tidak dipilih sebagai fitur secara
     bawaan untuk mencegah *data leakage*), serta label encoding.
3. **Training & Model** (2 tab): pembagian data latih/uji dan perhitungan Naive Bayes
   (rumus, prior, mean, varians, contoh perhitungan manual).
4. **Klasifikasi & Evaluasi** (3 tab): proses klasifikasi, evaluasi model (Accuracy,
   Precision, Recall, F1-Score, Confusion Matrix), dan hasil klasifikasi per siswa.
5. **Laporan / Hasil Akhir**: rangkuman lengkap serta ekspor Excel dan PDF.

## Cara Menjalankan

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Catatan Teknis

- Algoritma Naive Bayes: `core.GaussianNaiveBayesManual`, dihitung manual memakai NumPy
  (prior, mean, varians, PDF Gaussian, log-posterior).
- scikit-learn hanya dipakai untuk keperluan pendukung: `train_test_split`, `LabelEncoder`,
  dan metrik evaluasi (`accuracy_score`, dst.), bukan untuk algoritma Naive Bayes.
- Ekspor PDF membutuhkan `fpdf2` (sudah tercantum di `requirements.txt`).
- Tema warna diatur di `core.py` (bagian 1, `GLOBAL_CSS`) dan `.streamlit/config.toml`.
