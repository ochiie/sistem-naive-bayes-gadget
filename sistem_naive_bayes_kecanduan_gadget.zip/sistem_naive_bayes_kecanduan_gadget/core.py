"""
core.py
===============================================================================
SATU FILE BACKEND untuk Sistem Analisis Kecanduan Gadget pada Siswa (Naive Bayes).

Berisi SEMUA logika non-tampilan-halaman yang sebelumnya tersebar di banyak
file (utils/theme.py, utils/naive_bayes.py, utils/preprocessing.py,
utils/excel_reader.py, utils/report_generator.py, utils/activity_log.py,
utils/pipeline.py) — sengaja digabung menjadi satu file agar struktur
proyek tetap sederhana (sedikit file), namun isinya tetap lengkap.

Daftar isi (cari dengan Ctrl+F sesuai judul bagian):
    1. TEMA & KOMPONEN TAMPILAN (Tema Formal)
    2. PEMBACA EXCEL PINTAR (deteksi header, gabung sheet, pembuatan label)
    3. PREPROCESSING DATA (missing value, duplikat, encoding)
    4. ALGORITMA GAUSSIAN NAIVE BAYES (manual / from scratch)
    5. LOG AKTIVITAS
    6. PIPELINE ANALISIS (menjalankan seluruh alur sekaligus)
    7. GENERATOR LAPORAN (Excel & PDF)
===============================================================================
"""

import io
import re
from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix,
)


# ===============================================================================
# 1. TEMA & KOMPONEN TAMPILAN (Tema Formal)
# ===============================================================================

WARNA_UTAMA = "#31577F"

WARNA_KATEGORI = {
    "Rendah": "#2F6F4E",
    "Sedang": "#B7791F",
    "Tinggi": "#A61E22",
}

CMAP_FORMAL = "Blues"

GLOBAL_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Source+Serif+4:wght@600;700&display=swap');

:root{
    --navy:#31577F; --navy-deep:#294665; --ink:#1F2937; --muted:#5B6472;
    --line:#D5DBE5; --soft:#F3F5F9; --paper:#FFFFFF;
}

.stApp, .stApp p, .stApp label, .stApp input, .stApp textarea,
.stApp button, .stApp li, .stApp td, .stApp th{
    font-family:'Inter','Segoe UI',Arial,sans-serif;
}
[data-testid="stIconMaterial"]{font-family:'Material Symbols Rounded' !important;}

.stApp{background:linear-gradient(180deg,#f5f8fc 0%,#ffffff 34%,#ffffff 100%);color:var(--ink);}
.block-container{padding-top:1.5rem;padding-bottom:3rem;max-width:1220px;}
.main .block-container{position:relative;}

/* Bootstrap-inspired utility cards / hero */
.app-hero{position:relative;overflow:hidden;background:linear-gradient(135deg,#294665 0%,#3b648e 58%,#5d85b2 100%);border-radius:20px;padding:34px 40px;margin:0 0 24px;box-shadow:0 14px 35px rgba(15,47,87,.16);color:#fff;}
.app-hero:before{content:'';position:absolute;width:260px;height:260px;border-radius:50%;right:-80px;top:-120px;background:rgba(255,255,255,.10);}
.app-hero:after{content:'';position:absolute;width:180px;height:180px;border-radius:50%;right:100px;bottom:-120px;background:rgba(255,255,255,.07);}
.app-hero .eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.14em;font-weight:700;opacity:.82;margin-bottom:8px;}
.app-hero h1{font-family:'Inter','Segoe UI',Arial,sans-serif !important;color:#fff !important;font-size:2rem;margin:0 0 10px;font-weight:750;}
.app-hero p{max-width:760px;color:rgba(255,255,255,.86);font-size:.98rem;line-height:1.7;margin:0;}
.app-hero .hero-badge{display:inline-block;margin-top:18px;padding:7px 12px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.10);border-radius:999px;font-size:.78rem;font-weight:600;}
.choice-card{height:100%;min-height:245px;background:#fff;border:1px solid #dce5ef;border-radius:16px;padding:26px;box-shadow:0 7px 22px rgba(24,55,88,.07);transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease;}
.choice-card:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(24,55,88,.11);border-color:#b9cee4;}
.choice-icon{width:52px;height:52px;border-radius:14px;background:#eaf3fb;color:#1769aa;display:flex;align-items:center;justify-content:center;font-size:1.35rem;font-weight:800;margin-bottom:18px;}
.choice-card h3{font-family:'Inter','Segoe UI',Arial,sans-serif !important;font-size:1.12rem;color:#12385f;margin:0 0 8px;}
.choice-card p{font-size:.88rem;line-height:1.65;color:#66778b;margin:0 0 18px;}
.info-strip{background:#fff;border:1px solid #dce5ef;border-radius:14px;padding:15px 20px;box-shadow:0 5px 18px rgba(24,55,88,.05);}

/* Modern form cards */
div[data-testid='stForm'], div[data-testid='stExpander']{border-radius:14px !important;border-color:#dce5ef !important;box-shadow:0 5px 18px rgba(24,55,88,.045);}
.stTextInput input,.stNumberInput input,[data-baseweb='select']>div{border-radius:9px !important;border-color:#ccd9e6 !important;}
.stButton>button,.stDownloadButton>button,.stFormSubmitButton>button{border-radius:9px !important;min-height:42px;}


h1, h2, h3, h4{
    font-family:'Source Serif 4',Georgia,'Times New Roman',serif !important;
    color:var(--navy);
}
h5, h6{color:var(--navy);font-weight:600;}

/* -------------------- Tema NAVY khusus sidebar dan halaman Guru/Admin -------------------- */
[data-testid="stSidebar"]{background:linear-gradient(180deg,#10213f 0%,#172f55 55%,#1b365d 100%) !important;border-right:1px solid #263f64 !important;}
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p,
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stCaption{color:#e8eef8 !important;} [data-testid="stSidebar"] .sidebar-brand, [data-testid="stSidebar"] .sidebar-brand *{color:#FFFFFF !important;}
[data-testid="stSidebar"] h1,[data-testid="stSidebar"] h2,[data-testid="stSidebar"] h3{color:#ffffff !important;}
[data-testid="stSidebar"] [data-testid="stRadio"] label{background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.09);border-radius:9px;padding:7px 10px;margin:3px 0;}
[data-testid="stSidebar"] [data-testid="stRadio"] label:hover{background:rgba(255,255,255,.12);}
[data-testid="stSidebar"] [data-testid="stImage"]{border-radius:10px;}
.stApp [data-testid="stDataFrame"],.stApp [data-testid="stTable"]{border:1px solid #d6e0ee;border-radius:10px;overflow:hidden;}
.stApp [data-testid="stDataFrame"] thead th,.stApp table thead tr th{background:#31577f !important;color:#ffffff !important;}
.stApp .stButton>button,.stApp .stDownloadButton>button,.stApp .stFormSubmitButton>button{background:#31577f;color:#ffffff;border:1px solid #31577f;font-weight:600;box-shadow:0 3px 9px rgba(20,37,68,.12);}
.stApp .stButton>button:hover,.stApp .stDownloadButton>button:hover,.stApp .stFormSubmitButton>button:hover{background:#426d9b;color:#ffffff;border-color:#426d9b;}
.stApp [data-testid="stMetric"]{background:#fff;border:1px solid #d7e1ee;border-top:3px solid #1b365d;border-radius:12px;padding:14px 16px;box-shadow:0 4px 14px rgba(20,37,68,.06);}
.stApp [data-testid="stMetricLabel"]{color:#53657d;}
.stApp [data-testid="stMetricValue"]{color:#142544;}
.stApp [data-testid="stAlert"]{border-radius:10px;}

/* Sembunyikan elemen bawaan yang tidak diperlukan */
footer{visibility:hidden;}
.stDeployButton{display:none;}

/* -------------------- Judul halaman -------------------- */
.page-header{
    background:#fff;border:1px solid #dce5ef;border-left:5px solid #1b5f96;border-radius:13px;padding:18px 22px;margin-bottom:.5rem;box-shadow:0 4px 15px rgba(24,55,88,.04);
}
.page-header h1{
    margin:0;padding:0;font-size:1.65rem;font-weight:700;color:var(--navy);
    font-family:'Source Serif 4',Georgia,'Times New Roman',serif;
}
.page-sub{color:var(--muted);font-size:.92rem;margin:.6rem 0 1.5rem 0;line-height:1.6;}

.section-title{
    font-family:'Source Serif 4',Georgia,'Times New Roman',serif;
    font-size:1.08rem;font-weight:700;color:var(--navy);
    padding-bottom:.4rem;border-bottom:1px solid var(--line);
    margin:1.3rem 0 .9rem 0;
}
.section-title.rapat{margin-top:.1rem;}

/* -------------------- Kartu ringkasan -------------------- */
.metric-card{
    background:#fff;border:1px solid #dce5ef;border-top:3px solid #1b5f96;
    border-radius:13px;padding:17px 19px;height:100%;box-shadow:0 5px 18px rgba(24,55,88,.05);
}
.metric-card .label{
    font-size:.7rem;letter-spacing:.07em;text-transform:uppercase;
    color:var(--muted);font-weight:600;
}
.metric-card .value{
    font-weight:700;color:var(--navy);margin-top:5px;line-height:1.2;
    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}

.metric-mini{
    background:var(--soft);border:1px solid var(--line);border-radius:4px;
    padding:12px 16px;text-align:center;
}
.metric-mini .val{font-size:1.35rem;font-weight:700;color:var(--navy);}
.metric-mini .lab{
    font-size:.7rem;letter-spacing:.06em;text-transform:uppercase;
    color:var(--muted);font-weight:600;margin-top:2px;
}

div[data-testid="stMetric"]{
    background:var(--paper);border:1px solid var(--line);border-left:4px solid var(--navy);
    border-radius:4px;padding:12px 16px 8px 16px;
}
div[data-testid="stMetricValue"]{color:var(--navy);font-weight:700;}
div[data-testid="stMetricLabel"]{color:var(--muted);}

/* -------------------- Lencana status -------------------- */
.badge{
    display:inline-block;padding:4px 12px;border-radius:3px;
    font-size:.78rem;font-weight:600;margin:3px 8px 3px 0;border:1px solid transparent;
}
.badge-ok{background:#EAF4EE;color:#1E5B3D;border-color:#BFDDCB;}
.badge-warn{background:#FBF3E4;color:#7A5200;border-color:#EBD3A0;}
.badge-bad{background:#FBEAEA;color:#8F1D1D;border-color:#EDBDBD;}
.badge-info{background:#E8EEF7;color:#1B365D;border-color:#C3D0E4;}

/* -------------------- Berkas & aktivitas -------------------- */
.file-card{
    background:var(--soft);border:1px solid var(--line);border-radius:4px;
    padding:12px 16px;margin:.6rem 0 .9rem 0;
}
.file-card .name{font-weight:600;color:var(--navy);font-size:.92rem;word-break:break-all;}
.file-card .meta{color:var(--muted);font-size:.78rem;margin-top:2px;}

.step-row{
    display:flex;align-items:center;gap:12px;padding:10px 2px;
    border-bottom:1px solid var(--line);
}
.step-row:last-child{border-bottom:none;}
.step-no{
    width:24px;height:24px;border-radius:3px;display:flex;align-items:center;
    justify-content:center;font-size:.76rem;font-weight:700;flex-shrink:0;
}
.step-name{font-weight:600;color:var(--ink);font-size:.9rem;}
.step-status{margin-left:auto;font-size:.74rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;}

.activity-item{display:flex;gap:14px;padding:9px 2px;border-bottom:1px solid var(--line);}
.activity-item:last-child{border-bottom:none;}
.activity-time{
    font-size:.74rem;color:var(--muted);min-width:118px;padding-top:2px;
    font-variant-numeric:tabular-nums;
}
.activity-text{font-size:.86rem;color:var(--ink);line-height:1.4;}

.result-box{
    background:var(--soft);border:1px solid var(--line);border-left-width:6px;
    border-radius:4px;padding:16px 22px;margin-top:8px;
}
.result-box .result-label{
    font-size:.72rem;color:var(--muted);font-weight:700;letter-spacing:.08em;text-transform:uppercase;
}
.result-box .result-value{
    font-family:'Source Serif 4',Georgia,serif;font-size:1.55rem;font-weight:700;margin-top:4px;
}

.skala-tabel{width:100%;border-collapse:collapse;font-size:.88rem;margin:.4rem 0 .6rem 0;}
.skala-tabel th{
    background:var(--navy);color:#fff;text-align:left;padding:8px 12px;font-weight:600;
}
.skala-tabel td{padding:8px 12px;border-bottom:1px solid var(--line);}
.skala-tabel td.huruf{width:90px;font-weight:700;color:var(--navy);text-align:center;}

.footnote{color:var(--muted);font-size:.78rem;line-height:1.55;}

/* -------------------- Tombol -------------------- */
.stButton>button, .stDownloadButton>button, .stFormSubmitButton>button{
    border-radius:4px;font-weight:600;letter-spacing:.01em;
}

/* -------------------- Tab -------------------- */
.stTabs [data-baseweb="tab-list"]{gap:0;border-bottom:1px solid var(--line);}
.stTabs [data-baseweb="tab"]{
    background:transparent;padding:10px 20px;color:var(--muted);font-weight:600;
}
.stTabs [aria-selected="true"]{color:var(--navy) !important;}
.stTabs [data-baseweb="tab-highlight"]{background-color:var(--navy) !important;height:3px;}

/* -------------------- Komponen lain -------------------- */
details{border:1px solid var(--line) !important;border-radius:4px !important;background:var(--paper);}
[data-testid="stDataFrame"]{border:1px solid var(--line);border-radius:4px;overflow:hidden;}
div[data-testid="stAlert"]{border-radius:4px;}
hr{border-color:var(--line) !important;}

/* -------------------- Sidebar -------------------- */
section[data-testid="stSidebar"]{
    background:linear-gradient(180deg,#f7fbff 0%,#eef5fb 100%);border-right:1px solid #d6e2ee;
}
section[data-testid="stSidebar"] .stRadio [role="radiogroup"] label{
    padding:9px 12px;margin-bottom:3px;border-radius:3px;
    border-left:3px solid transparent;font-weight:500;color:var(--ink);
}
section[data-testid="stSidebar"] .stRadio [role="radiogroup"] label:has(input:checked){
    background:var(--paper);border-left:3px solid var(--navy);color:var(--navy);font-weight:600;
}
.sidebar-brand{padding:4px 2px 14px 2px;border-bottom:1px solid var(--line);margin-bottom:12px;}
.sidebar-brand .judul{
    font-family:'Source Serif 4',Georgia,serif;font-weight:700;color:var(--navy);font-size:1.05rem;
}
.sidebar-brand .peran{font-size:.76rem;color:#E7EEF8 !important;margin-top:2px;letter-spacing:.04em;text-transform:uppercase;}

/* Perbaikan navigasi admin: tanpa sorotan putih saat menu dipilih */
section[data-testid="stSidebar"]{
  background:linear-gradient(180deg,#243f63 0%,#1e3658 100%) !important;
  color:#ffffff !important;
}
section[data-testid="stSidebar"] .stRadio [role="radiogroup"] label,
[data-testid="stSidebar"] [data-testid="stRadio"] label{
  color:#ffffff !important;
  background:rgba(255,255,255,.035) !important;
  border:1px solid rgba(255,255,255,.10) !important;
  border-left:3px solid transparent !important;
  border-radius:9px !important;
  transition:background-color .15s ease,border-color .15s ease !important;
}
section[data-testid="stSidebar"] .stRadio [role="radiogroup"] label:hover,
[data-testid="stSidebar"] [data-testid="stRadio"] label:hover{
  color:#ffffff !important;
  background:rgba(126,176,230,.16) !important;
}
section[data-testid="stSidebar"] .stRadio [role="radiogroup"] label:has(input:checked),
[data-testid="stSidebar"] [data-testid="stRadio"] label:has(input:checked){
  color:#ffffff !important;
  background:#426b98 !important;
  border:1px solid #6f99c5 !important;
  border-left:3px solid #b9d9ff !important;
  box-shadow:none !important;
}
/* Tombol keluar selalu kontras dan terlihat */
section[data-testid="stSidebar"] div.stButton > button{
  width:100% !important;
  min-height:42px !important;
  background:#365b83 !important;
  color:#ffffff !important;
  border:1px solid #7799bd !important;
  border-radius:9px !important;
  font-weight:700 !important;
  opacity:1 !important;
  box-shadow:none !important;
}
section[data-testid="stSidebar"] div.stButton > button:hover{
  background:#527ba6 !important;
  color:#ffffff !important;
  border-color:#b9d9ff !important;
}
section[data-testid="stSidebar"] div.stButton > button:focus,
section[data-testid="stSidebar"] div.stButton > button:active{
  color:#ffffff !important;
  outline:2px solid rgba(185,217,255,.55) !important;
  outline-offset:1px !important;
  box-shadow:none !important;
}
/* Hilangkan kilatan putih/focus default pada kontrol utama */
.stApp .stButton > button:focus:not(:active),
.stApp .stButton > button:active,
.stApp [data-baseweb="tab"]:focus,
.stApp [data-baseweb="tab"]:active{
  box-shadow:none !important;
}

</style>
"""


def apply_global_style():
    """Panggil sekali di awal aplikasi untuk menerapkan tema formal yang konsisten."""
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


def render_page_header(title: str, subtitle: str = ""):
    sub_html = f'<p class="page-sub">{subtitle}</p>' if subtitle else ""
    st.markdown(f"""
    <div class="page-header"><h1>{title}</h1></div>
    {sub_html}
    """, unsafe_allow_html=True)


def render_section_title(teks: str, rapat: bool = False):
    """Judul bagian. `rapat=True` dipakai di dalam kartu agar jarak atasnya tidak berlebih."""
    kelas = "section-title rapat" if rapat else "section-title"
    st.markdown(f'<div class="{kelas}">{teks}</div>', unsafe_allow_html=True)


def render_metric_card(value, label: str, small_text: bool = False):
    ukuran = "1.1rem" if small_text else "1.55rem"
    st.markdown(f"""
    <div class="metric-card">
        <div class="label">{label}</div>
        <div class="value" style="font-size:{ukuran};">{value}</div>
    </div>
    """, unsafe_allow_html=True)


def render_metric_mini(value, label: str):
    st.markdown(
        f'<div class="metric-mini"><div class="val">{value}</div>'
        f'<div class="lab">{label}</div></div>',
        unsafe_allow_html=True,
    )


def render_step(nomor: int, nama: str, selesai: bool, aktif: bool = False):
    if selesai:
        bg, fg, teks = "#EAF4EE", "#1E5B3D", "Selesai"
    elif aktif:
        bg, fg, teks = "#FBF3E4", "#7A5200", "Berjalan"
    else:
        bg, fg, teks = "#F3F5F9", "#5B6472", "Menunggu"
    st.markdown(f"""
    <div class="step-row">
        <div class="step-no" style="background:{bg};color:{fg};">{nomor}</div>
        <div class="step-name">{nama}</div>
        <div class="step-status" style="color:{fg};">{teks}</div>
    </div>
    """, unsafe_allow_html=True)


def render_activity_item(teks: str, waktu: str):
    st.markdown(f"""
    <div class="activity-item">
        <div class="activity-time">{waktu}</div>
        <div class="activity-text">{teks}</div>
    </div>
    """, unsafe_allow_html=True)


# ===============================================================================
# 2. PEMBACA EXCEL PINTAR
# ===============================================================================

KATA_KUNCI_SHEET_BUKAN_DATA = ["petunjuk", "instruksi", "keterangan", "readme", "panduan"]
KATA_KUNCI_KOLOM_TARGET = ["kecandu", "tingkat", "kategori", "label", "klasifikasi"]
KATA_KUNCI_KOLOM_SKOR = ["skor", "total", "jumlah_poin", "nilai"]


def deteksi_baris_header(df_mentah: pd.DataFrame, maks_baris_scan: int = 15):
    """Mencari indeks baris yang paling mungkin merupakan baris header (nama kolom)."""
    n_scan = min(maks_baris_scan, len(df_mentah))
    for i in range(n_scan):
        baris = df_mentah.iloc[i]
        non_null = baris.notna().sum()
        if non_null < 2:
            continue
        non_null_str = baris.apply(lambda v: isinstance(v, str) and v.strip() != "").sum()
        unik = baris.dropna().astype(str).nunique()
        if non_null_str >= non_null * 0.6 and unik == non_null:
            if i + 1 < len(df_mentah) and df_mentah.iloc[i + 1].notna().sum() >= 2:
                return i
    return None


def _bersihkan_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Membuang kolom & baris kosong total, serta baris catatan kaki di akhir."""
    df = df.dropna(axis=1, how="all")
    df = df.dropna(axis=0, how="all")

    def baris_catatan_kaki(baris) -> bool:
        nilai_terisi = baris.dropna()
        if len(nilai_terisi) != 1:
            return False
        teks = str(nilai_terisi.iloc[0]).strip().lower()
        return teks.startswith(("catatan", "keterangan", "sumber", "note"))

    baris_dibuang = df.apply(baris_catatan_kaki, axis=1)
    df = df.loc[~baris_dibuang]

    df.columns = [str(c).strip() for c in df.columns]
    return df.reset_index(drop=True)


def baca_sheet_pintar(file_like, nama_sheet: str):
    """Membaca satu sheet Excel, mendeteksi baris header, dan membersihkannya."""
    if any(kw in nama_sheet.lower() for kw in KATA_KUNCI_SHEET_BUKAN_DATA):
        return None

    df_mentah = pd.read_excel(file_like, sheet_name=nama_sheet, header=None)
    idx_header = deteksi_baris_header(df_mentah)
    if idx_header is None:
        return None

    header = df_mentah.iloc[idx_header]
    df = df_mentah.iloc[idx_header + 1:].copy()
    df.columns = header
    df = _bersihkan_dataframe(df)

    if df.shape[0] < 1 or df.shape[1] < 2:
        return None
    return df


def baca_semua_sheet(file_like) -> dict:
    """Membaca seluruh sheet dalam file Excel yang bisa diunggah."""
    xls = pd.ExcelFile(file_like)
    hasil = {}
    for nama_sheet in xls.sheet_names:
        df = baca_sheet_pintar(xls, nama_sheet)
        if df is not None:
            hasil[nama_sheet] = df
    return hasil


def sheet_bisa_digabung(dict_sheet: dict) -> bool:
    """Cek apakah semua sheet valid punya struktur kolom sama persis."""
    if len(dict_sheet) < 2:
        return False
    daftar_kolom = [tuple(df.columns) for df in dict_sheet.values()]
    return all(k == daftar_kolom[0] for k in daftar_kolom)


def gabungkan_sheet(dict_sheet: dict, kolom_sumber: str = "Sumber Sheet") -> pd.DataFrame:
    """Menggabungkan beberapa sheet (struktur kolom sama) menjadi satu DataFrame."""
    potongan = []
    for nama_sheet, df in dict_sheet.items():
        bagian = df.copy()
        if kolom_sumber not in bagian.columns:
            bagian.insert(0, kolom_sumber, nama_sheet)
        potongan.append(bagian)
    return pd.concat(potongan, ignore_index=True)


def cari_kolom_target_kategorikal(df: pd.DataFrame):
    """Mencari kolom yang kemungkinan besar sudah berupa label kategori target."""
    for kolom in df.columns:
        nama = str(kolom).lower()
        if any(kw in nama for kw in KATA_KUNCI_KOLOM_TARGET):
            n_unik = df[kolom].nunique(dropna=True)
            if 2 <= n_unik <= 6:
                return kolom
    return None


def cari_kolom_skor_numerik(df: pd.DataFrame):
    """Mencari kolom numerik yang kemungkinan besar adalah skor total kuesioner."""
    kandidat_nama = [c for c in df.columns if any(kw in str(c).lower() for kw in KATA_KUNCI_KOLOM_SKOR)]
    for kolom in kandidat_nama:
        if pd.api.types.is_numeric_dtype(pd.to_numeric(df[kolom], errors="coerce")):
            return kolom
    return None


def buat_label_kategori(df: pd.DataFrame, kolom_skor: str,
                         nama_kategori=("Rendah", "Sedang", "Tinggi")) -> pd.Series:
    """Membuat kolom kategori dari kolom skor numerik (interval sama besar)."""
    skor = pd.to_numeric(df[kolom_skor], errors="coerce")
    return pd.cut(skor, bins=len(nama_kategori), labels=list(nama_kategori), include_lowest=True)


def lengkapi_label_dari_skor(df: pd.DataFrame, kolom_label: str = "Tingkat_Kecanduan",
                              kolom_skor: str = "Total Skor") -> pd.DataFrame:
    """
    Mengisi label yang kosong atau berstatus sementara berdasarkan Total Skor, memakai batas
    tetap sesuai rentang instrumen (15-75 dibagi tiga): Rendah 15-35, Sedang 36-55, Tinggi 56-75.
    Label yang sudah terisi tidak diubah.
    """
    df = df.copy()
    if kolom_skor not in df.columns:
        return df
    if kolom_label not in df.columns:
        df[kolom_label] = pd.NA
    skor = pd.to_numeric(df[kolom_skor], errors="coerce")
    dari_skor = pd.cut(skor, bins=[0, 35, 55, 75], labels=["Rendah", "Sedang", "Tinggi"]).astype("object")
    kosong = df[kolom_label].isna() | df[kolom_label].astype(str).isin(["", "Menunggu Model Dilatih"])
    df[kolom_label] = df[kolom_label].astype("object").where(~kosong, dari_skor)
    return df


# ===============================================================================
# 3. PREPROCESSING DATA
# ===============================================================================

def ringkasan_missing_value(df: pd.DataFrame) -> pd.DataFrame:
    """Tabel ringkasan jumlah & persentase missing value tiap kolom."""
    total = df.isnull().sum()
    persen = (df.isnull().sum() / len(df) * 100).round(2)
    ringkasan = pd.DataFrame({
        "Kolom": df.columns,
        "Tipe Data": df.dtypes.astype(str).values,
        "Jumlah Missing": total.values,
        "Persentase Missing (%)": persen.values,
    })
    return ringkasan.reset_index(drop=True)


def tangani_missing_value(df: pd.DataFrame, metode: str = "hapus_baris") -> pd.DataFrame:
    """
    metode:
        - "hapus_baris": menghapus baris yang mengandung nilai kosong
        - "isi_rata_median": mengisi numerik dengan median, kategorik dengan modus
    """
    df = df.copy()
    if metode == "hapus_baris":
        df = df.dropna().reset_index(drop=True)
    elif metode == "isi_rata_median":
        for col in df.columns:
            if df[col].isnull().sum() == 0:
                continue
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].median())
            else:
                modus = df[col].mode(dropna=True)
                nilai_isi = modus.iloc[0] if not modus.empty else "Tidak Diketahui"
                df[col] = df[col].fillna(nilai_isi)
    return df


def hapus_duplikat(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=True)


def encode_fitur_dan_target(df: pd.DataFrame, feature_cols: list, target_col: str):
    """
    Label encoding untuk kolom fitur & target yang bertipe kategorik/teks.
    Return: df_encoded, encoders (dict), target_encoder (atau None jika target sudah numerik)
    """
    df_encoded = df[feature_cols + [target_col]].copy()
    encoders = {}

    for col in feature_cols:
        if not pd.api.types.is_numeric_dtype(df_encoded[col]):
            le = LabelEncoder()
            df_encoded[col] = le.fit_transform(df_encoded[col].astype(str))
            encoders[col] = le
        else:
            df_encoded[col] = df_encoded[col].astype(float)

    target_encoder = None
    if not pd.api.types.is_numeric_dtype(df_encoded[target_col]):
        target_encoder = LabelEncoder()
        df_encoded[target_col] = target_encoder.fit_transform(df_encoded[target_col].astype(str))

    return df_encoded, encoders, target_encoder


def deteksi_kolom_identitas(df: pd.DataFrame) -> list:
    """Menebak kolom identitas (Nama, NIS, Kelas, dll) berdasarkan token nama kolom."""
    kandidat_kata = {"nama", "nis", "nisn", "no", "id", "kelas",
                      "jenis", "kelamin", "gender", "usia", "umur"}
    hasil = []
    for col in df.columns:
        nama_lower = str(col).strip().lower()
        token_list = re.split(r"[\s_\-\.]+", nama_lower)
        token_set = set(t for t in token_list if t)
        if nama_lower in kandidat_kata or (token_set & kandidat_kata):
            hasil.append(col)
    return hasil


# ===============================================================================
# 4. ALGORITMA GAUSSIAN NAIVE BAYES (MANUAL / FROM SCRATCH)
# ===============================================================================

class GaussianNaiveBayesManual:
    """
    Gaussian Naive Bayes diimplementasikan manual dari nol dengan numpy —
    TIDAK memakai fungsi fit/predict siap pakai dari scikit-learn.

    Rumus dasar:
        P(Ck | x1,...,xn) ~ P(Ck) * Prod_i P(xi | Ck)
        P(xi | Ck) = 1/sqrt(2*pi*var_ck) * exp( -(xi-mean_ck)^2 / (2*var_ck) )

    Perhitungan posterior dilakukan di ruang logaritma agar stabil secara numerik.
    """

    def __init__(self, var_smoothing: float = 1e-9):
        self.var_smoothing = var_smoothing
        self.classes_ = None
        self.mean_ = {}
        self.var_ = {}
        self.prior_ = {}
        self.feature_names_ = None
        self.n_features_ = None

    def fit(self, X, y, feature_names=None):
        """Melatih model: menghitung mean, varians, dan prior tiap kelas."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)

        self.n_features_ = X.shape[1]
        self.feature_names_ = (
            list(feature_names) if feature_names is not None
            else [f"X{i+1}" for i in range(self.n_features_)]
        )
        self.classes_ = np.unique(y)
        n_samples = X.shape[0]

        global_var = X.var(axis=0).max() if X.shape[0] > 0 else 1.0
        eps = self.var_smoothing * (global_var if global_var > 0 else 1.0)

        for c in self.classes_:
            X_c = X[y == c]
            self.mean_[c] = X_c.mean(axis=0)
            self.var_[c] = X_c.var(axis=0) + eps
            self.prior_[c] = X_c.shape[0] / n_samples

        return self

    def _gaussian_log_pdf(self, x_col, mean, var):
        return -0.5 * np.log(2.0 * np.pi * var) - ((x_col - mean) ** 2) / (2.0 * var)

    def _joint_log_likelihood(self, X):
        X = np.asarray(X, dtype=float)
        n_samples = X.shape[0]
        log_probs = np.zeros((n_samples, len(self.classes_)))

        for idx, c in enumerate(self.classes_):
            log_prior = np.log(self.prior_[c])
            log_likelihood = self._gaussian_log_pdf(X, self.mean_[c], self.var_[c]).sum(axis=1)
            log_probs[:, idx] = log_prior + log_likelihood

        return log_probs

    def predict_proba(self, X):
        """Probabilitas posterior tiap kelas, dinormalisasi (log-sum-exp trick)."""
        log_probs = self._joint_log_likelihood(X)
        max_log = np.max(log_probs, axis=1, keepdims=True)
        exp_shifted = np.exp(log_probs - max_log)
        proba = exp_shifted / exp_shifted.sum(axis=1, keepdims=True)
        return proba

    def predict(self, X):
        """Label kelas dengan probabilitas posterior tertinggi."""
        proba = self.predict_proba(X)
        idx = np.argmax(proba, axis=1)
        return self.classes_[idx]

    def get_prior_table(self):
        return pd.DataFrame({
            "Kelas": self.classes_,
            "P(Kelas) - Prior": [self.prior_[c] for c in self.classes_],
        })

    def get_mean_var_table(self):
        rows = []
        for c in self.classes_:
            for i, fname in enumerate(self.feature_names_):
                rows.append({
                    "Kelas": c,
                    "Fitur": fname,
                    "Mean (μ)": self.mean_[c][i],
                    "Varians (σ²)": self.var_[c][i],
                })
        return pd.DataFrame(rows)

    def explain_single_prediction(self, x_row):
        """Tabel rincian perhitungan posterior untuk 1 baris data (ilustrasi manual)."""
        x_row = np.asarray(x_row, dtype=float)
        rows = []
        log_probs = {}
        for c in self.classes_:
            log_prior = np.log(self.prior_[c])
            log_lik_per_feature = self._gaussian_log_pdf(x_row, self.mean_[c], self.var_[c])
            total_log = log_prior + log_lik_per_feature.sum()
            log_probs[c] = total_log
            rows.append({
                "Kelas": c,
                "log P(Kelas)": log_prior,
                "Sum log P(xi|Kelas)": log_lik_per_feature.sum(),
                "log Posterior (~)": total_log,
            })
        detail_df = pd.DataFrame(rows)

        max_log = max(log_probs.values())
        exp_shifted = {c: np.exp(v - max_log) for c, v in log_probs.items()}
        total = sum(exp_shifted.values())
        posterior = {c: v / total for c, v in exp_shifted.items()}
        detail_df["Posterior Ternormalisasi"] = detail_df["Kelas"].map(posterior)
        predicted_class = max(posterior, key=posterior.get)
        return detail_df, predicted_class


# ===============================================================================
# 5. LOG AKTIVITAS
# ===============================================================================

MAKS_RIWAYAT = 8


def log_activity(pesan: str) -> None:
    """Menyimpan satu entri aktivitas terbaru ke session_state (untuk Dashboard)."""
    if st.session_state.get("activity_log") is None:
        st.session_state["activity_log"] = []

    entri = {
        "waktu": datetime.now().strftime("%H:%M:%S"),
        "tanggal": datetime.now().strftime("%d/%m/%Y"),
        "pesan": pesan,
    }
    st.session_state["activity_log"].insert(0, entri)
    st.session_state["activity_log"] = st.session_state["activity_log"][:MAKS_RIWAYAT]


# ===============================================================================
# 6. PIPELINE ANALISIS (Preprocessing -> Split -> Training -> Klasifikasi -> Evaluasi)
# ===============================================================================

def _deteksi_target(df: pd.DataFrame):
    target_col = cari_kolom_target_kategorikal(df)
    if target_col is not None:
        return target_col
    kolom_terakhir = df.columns[-1]
    n_unik = df[kolom_terakhir].nunique(dropna=True)
    if 2 <= n_unik <= 10:
        return kolom_terakhir
    return None


def _kolom_skor_total(df: pd.DataFrame) -> list:
    """Kolom skor total/rekap yang dikeluarkan dari fitur agar tidak terjadi
    data leakage (model tidak boleh 'mencontek' dari kolom sumber labelnya sendiri)."""
    return [c for c in df.columns if any(kw in str(c).lower() for kw in KATA_KUNCI_KOLOM_SKOR)]


def kolom_skor_atau_rekap(df: pd.DataFrame) -> list:
    """Versi publik dari _kolom_skor_total — dipakai halaman Preprocessing agar kolom
    seperti 'Total Skor' tidak diikutkan sebagai fitur (mencegah data leakage)."""
    return _kolom_skor_total(df)


def jalankan_pipeline_analisis(df_final: pd.DataFrame) -> dict:
    """
    Menjalankan seluruh pipeline analisis begitu dataset diimpor,
    mengisi st.session_state seolah pengguna sudah menjalankan setiap tahap manual.
    Melempar ValueError (berisi pesan jelas) jika alur analisis tidak dapat dijalankan.
    """
    target_col = _deteksi_target(df_final)
    if target_col is None:
        raise ValueError(
            "Kolom target/label tidak dapat dikenali. Silakan pilih kolom "
            "target & fitur secara manual di menu **Preprocessing Data**."
        )

    kolom_identitas = deteksi_kolom_identitas(df_final)
    kolom_skor_sumber = [c for c in _kolom_skor_total(df_final) if c != target_col]
    feature_cols = [c for c in df_final.columns
                    if c != target_col and c not in kolom_identitas
                    and c not in kolom_skor_sumber and c != "Sumber Sheet"]

    if not feature_cols:
        raise ValueError(
            "Tidak ada kolom fitur yang tersisa setelah menyaring kolom identitas. "
            "Silakan pilih kolom fitur secara manual di menu **Preprocessing Data**."
        )

    df_bersih = tangani_missing_value(df_final, metode="isi_rata_median")
    df_bersih = hapus_duplikat(df_bersih)

    if df_bersih.empty or df_bersih[target_col].nunique(dropna=True) < 2:
        raise ValueError(
            "Data tidak cukup setelah dibersihkan (kosong atau kelas target "
            "kurang dari 2). Silakan atur ulang secara manual di menu **Preprocessing Data**."
        )

    df_encoded, label_encoders, target_encoder = encode_fitur_dan_target(
        df_bersih, feature_cols, target_col
    )

    st.session_state["df_clean"] = df_encoded
    st.session_state["feature_cols"] = feature_cols
    st.session_state["target_col"] = target_col
    st.session_state["label_encoders"] = label_encoders
    st.session_state["target_encoder"] = target_encoder
    st.session_state["df_clean_asli"] = df_bersih
    log_activity(f"Preprocessing selesai ({len(df_encoded)} baris siap dianalisis)")

    X = df_encoded[feature_cols].values
    y = df_encoded[target_col].values
    idx_all = df_encoded.index.values

    try:
        X_train, X_test, y_train, y_test, train_idx, test_idx = train_test_split(
            X, y, idx_all, test_size=0.2, random_state=42, stratify=y
        )
    except ValueError:
        X_train, X_test, y_train, y_test, train_idx, test_idx = train_test_split(
            X, y, idx_all, test_size=0.2, random_state=42
        )

    st.session_state["X_train"] = X_train
    st.session_state["X_test"] = X_test
    st.session_state["y_train"] = y_train
    st.session_state["y_test"] = y_test
    st.session_state["train_idx"] = train_idx
    st.session_state["test_idx"] = test_idx
    log_activity(f"Pembagian data: {len(X_train)} training, {len(X_test)} testing")

    model = GaussianNaiveBayesManual()
    model.fit(X_train, y_train, feature_names=feature_cols)
    st.session_state["model"] = model
    log_activity("Model Naive Bayes berhasil dilatih")

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)
    st.session_state["y_pred"] = y_pred
    st.session_state["y_proba"] = y_proba
    log_activity(f"Klasifikasi untuk {len(X_test)} data testing")

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average="macro", zero_division=0)
    recall = recall_score(y_test, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_test, y_pred, average="macro", zero_division=0)
    cm = confusion_matrix(y_test, y_pred, labels=model.classes_)

    metrics = {
        "Accuracy": accuracy,
        "Precision (macro avg)": precision,
        "Recall (macro avg)": recall,
        "F1-Score (macro avg)": f1,
    }
    st.session_state["metrics"] = metrics
    st.session_state["confusion_matrix"] = cm
    log_activity(f"Evaluasi selesai (Accuracy {accuracy*100:.1f}%)")

    def label_terbaca(arr):
        if target_encoder is not None:
            return target_encoder.inverse_transform(arr)
        return arr

    hasil = pd.DataFrame({
        "Label Aktual": label_terbaca(y_test),
        "Label Prediksi": label_terbaca(y_pred),
    })
    hasil["Status"] = ["Sesuai" if a == p else "Tidak Sesuai"
                        for a, p in zip(hasil["Label Aktual"], hasil["Label Prediksi"])]

    identitas_cols = [c for c in df_bersih.columns if c not in feature_cols + [target_col]]
    if identitas_cols:
        identitas_df = df_bersih.loc[test_idx, identitas_cols].reset_index(drop=True)
        hasil = pd.concat([identitas_df, hasil], axis=1)

    st.session_state["hasil_klasifikasi_df"] = hasil

    ringkasan = hasil["Label Prediksi"].value_counts().reset_index()
    ringkasan.columns = ["Kategori Kecanduan", "Jumlah Siswa"]
    st.session_state["ringkasan_kelas"] = ringkasan

    X_all = df_encoded[feature_cols].values
    pred_all = model.predict(X_all)
    hasil_all = df_bersih[identitas_cols].reset_index(drop=True).copy() if identitas_cols else pd.DataFrame()
    hasil_all["Label Aktual"] = label_terbaca(df_encoded[target_col].values)
    hasil_all["Label Prediksi (Model)"] = label_terbaca(pred_all)
    st.session_state["hasil_seluruh_data"] = hasil_all

    log_activity(f"Mengklasifikasikan seluruh data ({len(hasil_all)} siswa)")

    return {
        "target_col": target_col,
        "feature_cols": feature_cols,
        "jumlah_data": len(df_encoded),
        "jumlah_train": len(X_train),
        "jumlah_test": len(X_test),
        "metrics": metrics,
    }


# ===============================================================================
# 7. GENERATOR LAPORAN (Excel & PDF)
# ===============================================================================

def generate_excel_report(hasil_df: pd.DataFrame, metrics: dict, ringkasan_kelas: pd.DataFrame) -> bytes:
    """Membuat laporan Excel multi-sheet dan mengembalikannya sebagai bytes."""
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        hasil_df.to_excel(writer, sheet_name="Hasil Klasifikasi", index=False)

        metrik_df = pd.DataFrame({
            "Metrik": list(metrics.keys()),
            "Nilai": list(metrics.values()),
        })
        metrik_df.to_excel(writer, sheet_name="Evaluasi Model", index=False)

        ringkasan_kelas.to_excel(writer, sheet_name="Ringkasan Kategori", index=False)

    buffer.seek(0)
    return buffer.getvalue()


def generate_pdf_report(judul: str, metrics: dict, ringkasan_kelas: pd.DataFrame,
                         jumlah_data: int, jumlah_train: int, jumlah_test: int) -> bytes:
    """Membuat laporan ringkas PDF memakai fpdf2 (ImportError ditangani di halaman)."""
    from fpdf import FPDF

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, judul, ln=True, align="C")

    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 8, f"Tanggal Cetak: {datetime.now().strftime('%d-%m-%Y %H:%M')}", ln=True)
    pdf.ln(4)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "1. Ringkasan Dataset", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 7, f"Jumlah Total Data Siswa : {jumlah_data}", ln=True)
    pdf.cell(0, 7, f"Jumlah Data Training    : {jumlah_train}", ln=True)
    pdf.cell(0, 7, f"Jumlah Data Testing     : {jumlah_test}", ln=True)
    pdf.ln(3)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "2. Evaluasi Model Naive Bayes", ln=True)
    pdf.set_font("Helvetica", "", 10)
    for k, v in metrics.items():
        if isinstance(v, float):
            pdf.cell(0, 7, f"{k} : {v:.4f}", ln=True)
        else:
            pdf.cell(0, 7, f"{k} : {v}", ln=True)
    pdf.ln(3)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "3. Ringkasan Jumlah Siswa per Kategori Kecanduan", ln=True)
    pdf.set_font("Helvetica", "B", 10)
    col_w = 90
    pdf.cell(col_w, 7, "Kategori", border=1)
    pdf.cell(col_w, 7, "Jumlah Siswa", border=1, ln=True)
    pdf.set_font("Helvetica", "", 10)
    for _, row in ringkasan_kelas.iterrows():
        pdf.cell(col_w, 7, str(row.iloc[0]), border=1)
        pdf.cell(col_w, 7, str(row.iloc[1]), border=1, ln=True)

    return bytes(pdf.output())
