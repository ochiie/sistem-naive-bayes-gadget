"""
buat_secrets.py - Membuat file .streamlit/secrets.toml dengan format yang pasti benar.

Cara pakai (di terminal, di folder yang berisi app.py):
    python buat_secrets.py

Anda hanya diminta menempel dua nilai dari Supabase. Spasi, tanda kutip, dan baris
baru yang ikut tersalin dibersihkan otomatis. Setelah file dibuat, sambungan langsung diperiksa.
"""
import os
import subprocess
import sys

FOLDER = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(FOLDER, ".streamlit", "secrets.toml")
KUTIP = "\"'\u201c\u201d\u2018\u2019` \t\r\n"


def bersihkan(teks: str) -> str:
    teks = teks.strip().strip(KUTIP)
    return "".join(teks.split())          # buang spasi/baris baru di tengah


def tanya(pesan: str) -> str:
    try:
        return bersihkan(input(pesan))
    except (EOFError, KeyboardInterrupt):
        print("\nDibatalkan.")
        sys.exit(1)


print("=== Pembuatan secrets.toml ===\n")
print("Buka dashboard Supabase, lalu salin nilainya dengan tombol Copy (jangan diketik).\n")

while True:
    url = tanya("1) Tempel Project URL (https://....supabase.co), lalu tekan Enter:\n   > ")
    if url.endswith("/rest/v1") or url.endswith("/rest/v1/"):
        url = url.split("/rest/v1")[0]
    url = url.rstrip("/")
    if url.startswith("https://") and url.endswith(".supabase.co") and "xxxx" not in url:
        break
    print("   Bentuknya belum benar. Harus seperti https://abcdefgh.supabase.co  (coba salin ulang).\n")

while True:
    key = tanya("\n2) Tempel Publishable key (sb_publishable_...) atau anon key (eyJ...), lalu Enter:\n   > ")
    if key.startswith("sb_secret_"):
        print("   Itu SECRET key. Jangan dipakai. Salin yang 'Publishable key'.\n")
    elif key.startswith("sb_publishable_") or key.startswith("eyJ"):
        break
    else:
        print("   Awalannya tidak dikenali (harus sb_publishable_ atau eyJ). Coba salin ulang.\n")

os.makedirs(os.path.dirname(TARGET), exist_ok=True)
if os.path.isfile(TARGET):
    cadangan = TARGET + ".bak"
    try:
        if os.path.isfile(cadangan):
            os.remove(cadangan)
        os.replace(TARGET, cadangan)
        print(f"\nFile lama dicadangkan ke: {cadangan}")
    except OSError:
        pass

with open(TARGET, "w", encoding="utf-8", newline="\n") as f:
    f.write(f'SUPABASE_URL = "{url}"\nSUPABASE_KEY = "{key}"\n')
print(f"\n[OK] File dibuat: {TARGET}")

print("\nMemeriksa sambungan...\n")
cek = os.path.join(FOLDER, "cek_koneksi.py")
if os.path.isfile(cek):
    subprocess.run([sys.executable, cek], cwd=FOLDER)
else:
    print("cek_koneksi.py tidak ditemukan; lewati pemeriksaan.")
