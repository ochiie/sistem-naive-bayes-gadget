"""
cek_koneksi.py - Memeriksa sambungan ke Supabase TANPA membuka aplikasi.

Cara pakai (di terminal, di dalam folder proyek ini):
    python cek_koneksi.py

Hasilnya menyebut dengan jelas apa yang masih salah. Kunci tidak ditampilkan utuh.
"""
import os
import re
import sys

try:
    import requests
except ImportError:
    print("Library 'requests' belum terpasang. Jalankan:  pip install -r requirements.txt")
    sys.exit(1)

FOLDER = os.path.dirname(os.path.abspath(__file__))
KANDIDAT = [
    os.path.join(os.getcwd(), ".streamlit", "secrets.toml"),
    os.path.join(FOLDER, ".streamlit", "secrets.toml"),
    os.path.join(os.path.expanduser("~"), ".streamlit", "secrets.toml"),
]


def baca_nilai(teks, nama):
    m = re.search(rf'^\s*{nama}\s*=\s*"([^"]*)"', teks, flags=re.M)
    return m.group(1).strip() if m else ""


def topeng(k):
    return (k[:14] + "..." + k[-4:]) if len(k) > 20 else "(terlalu pendek)"


print("=== Pemeriksaan sambungan Supabase ===\n")

berkas = next((p for p in KANDIDAT if os.path.isfile(p)), None)
if not berkas:
    print("[GAGAL] File secrets.toml tidak ditemukan. Tempat yang diperiksa:")
    for p in KANDIDAT:
        print("   -", p)
    ada_contoh = os.path.isfile(os.path.join(FOLDER, ".streamlit", "secrets.toml.example"))
    print("\nSolusi: salin secrets.toml.example menjadi secrets.toml di folder")
    print("   " + os.path.join(FOLDER, ".streamlit"))
    if os.path.isfile(os.path.join(FOLDER, ".streamlit", "secrets.toml.txt")):
        print("   Ditemukan 'secrets.toml.txt'. Ganti namanya menjadi 'secrets.toml' (hapus .txt).")
    sys.exit(1)

print("[OK] File secrets ditemukan:", berkas)
isi = open(berkas, encoding="utf-8-sig").read()

if any(ch in isi for ch in "\u201c\u201d\u2018\u2019"):
    print("[GAGAL] Ada tanda kutip MELENGKUNG di file. Ganti semuanya dengan tanda kutip lurus (\").")
    print("   Biasanya terjadi karena disalin dari Word/WhatsApp. Ketik ulang tanda kutipnya di Notepad.")
    sys.exit(1)

try:
    import tomllib
    data = tomllib.loads(isi)
    print("[OK] Format file TOML valid.")
except ImportError:
    data = None
    print("[INFO] Python Anda lebih lama dari 3.11, format TOML diperiksa sederhana saja.")
except Exception as e:
    print(f"[GAGAL] Format file tidak valid: {e}")
    print("   Pastikan tiap baris berbentuk:  NAMA = \"nilai\"  tanpa spasi/baris baru di dalam kutip.")
    sys.exit(1)

if data is not None:
    url = str(data.get("SUPABASE_URL", "")).strip().rstrip("/")
    key = str(data.get("SUPABASE_KEY", "")).strip()
else:
    url = baca_nilai(isi, "SUPABASE_URL").rstrip("/")
    key = baca_nilai(isi, "SUPABASE_KEY")

print("Folder kerja terminal saat ini:", os.getcwd())
print("   (aplikasi Streamlit harus dijalankan dari folder yang berisi .streamlit\\secrets.toml)")

salah = False
if not url or "xxxx" in url:
    print("[GAGAL] SUPABASE_URL masih kosong atau masih teks contoh (xxxx).")
    salah = True
elif not (url.startswith("https://") and url.endswith(".supabase.co")):
    print(f"[GAGAL] SUPABASE_URL tidak berbentuk https://....supabase.co  (isinya: {url})")
    salah = True
else:
    print("[OK] SUPABASE_URL berbentuk benar:", url)

if not key or "isi-dengan" in key or "xxxx" in key:
    print("[GAGAL] SUPABASE_KEY masih kosong atau masih teks contoh.")
    salah = True
elif key.startswith("sb_secret_") or key.count(".") == 2 and "service_role" in key:
    print("[GAGAL] Ini kunci RAHASIA (secret/service_role). Pakai Publishable key atau anon key.")
    salah = True
elif key.startswith("sb_publishable_") or key.startswith("eyJ"):
    print("[OK] Jenis kunci dikenali:", topeng(key))
else:
    print("[PERINGATAN] Awalan kunci tidak dikenali (seharusnya sb_publishable_ atau eyJ):", topeng(key))
if salah:
    print("\nPerbaiki file di atas, simpan, lalu jalankan skrip ini lagi.")
    sys.exit(1)

h = {"apikey": key, "Content-Type": "application/json"}
if key.startswith("eyJ"):
    h["Authorization"] = f"Bearer {key}"

print("\nMenghubungi server...")
try:
    r = requests.get(f"{url}/rest/v1/jawaban_kuesioner", params={"select": "id", "limit": 1},
                     headers=h, timeout=15)
except requests.exceptions.RequestException as e:
    print(f"[GAGAL] Tidak dapat menjangkau server ({type(e).__name__}).")
    print("   Periksa koneksi internet dan ketik ulang URL (salin dengan tombol Copy).")
    sys.exit(1)

if r.status_code == 200:
    print("[BERHASIL] Terhubung, dan tabel 'jawaban_kuesioner' ditemukan.")
    print("Jalankan ulang aplikasi (Ctrl+C lalu: streamlit run app.py). Badge akan hijau.")
elif r.status_code in (401, 403):
    print(f"[GAGAL] Ditolak (kode {r.status_code}). Rincian: {r.text[:200]}")
    print("   Kemungkinan: kunci salah salin, atau izin tabel belum diberikan.")
    print("   Jalankan di SQL Editor Supabase:")
    print("   grant usage on schema public to anon, authenticated;")
    print("   grant select, insert on public.jawaban_kuesioner to anon, authenticated;")
elif r.status_code == 404 or "does not exist" in r.text or "schema cache" in r.text:
    print("[GAGAL] Server terjangkau, tetapi tabel 'jawaban_kuesioner' belum ada.")
    print("   Jalankan isi file supabase_setup.sql di SQL Editor Supabase.")
else:
    print(f"[GAGAL] Kode {r.status_code}: {r.text[:300]}")
