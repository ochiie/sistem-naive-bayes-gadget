"""Penyimpanan lokal permanen menggunakan SQLite. Tidak perlu Supabase/XAMPP."""
import os, sqlite3
from datetime import datetime
import pandas as pd
import streamlit as st

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "jawaban_siswa.db")
KOLOM_PERTANYAAN_DB = [f"p{i}" for i in range(1, 16)]
KOLOM_PERTANYAAN_TAMPIL = [f"P{i}" for i in range(1, 16)]
LABEL_BELUM_ADA = "Menunggu Model Dilatih"

def _conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS jawaban_kuesioner (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT, kelas TEXT, jenis_kelamin TEXT, usia TEXT,
        total_skor REAL, tingkat_kecanduan TEXT,
        waktu_pengisian TEXT,
        p1 TEXT, p2 TEXT, p3 TEXT, p4 TEXT, p5 TEXT,
        p6 TEXT, p7 TEXT, p8 TEXT, p9 TEXT, p10 TEXT,
        p11 TEXT, p12 TEXT, p13 TEXT, p14 TEXT, p15 TEXT
    )""")
    conn.commit()
    return conn

def _simpan_galat(pesan):
    try: st.session_state["db_galat_terakhir"] = pesan
    except Exception: pass

def galat_terakhir():
    try: return st.session_state.get("db_galat_terakhir", "")
    except Exception: return ""

def status_koneksi():
    try:
        with _conn() as c: c.execute("SELECT 1")
        return {"terhubung": True, "pesan": "Penyimpanan lokal aktif — jawaban disimpan permanen di file data/jawaban_siswa.db."}
    except Exception as e:
        return {"terhubung": False, "pesan": f"Penyimpanan lokal gagal: {e}"}

def segarkan_status():
    pass

def _bersih(v):
    if v is None: return None
    try:
        if pd.isna(v): return None
    except (TypeError, ValueError): pass
    if hasattr(v, "item"): v = v.item()
    return v

def _baris_ke_format_db(row):
    label = row.get("Tingkat_Kecanduan (Prediksi Sistem)") or row.get("Tingkat_Kecanduan")
    if label == LABEL_BELUM_ADA: label = None
    data = {"nama": _bersih(row.get("Nama")), "kelas": _bersih(row.get("Kelas")),
            "jenis_kelamin": _bersih(row.get("Jenis Kelamin")), "usia": _bersih(row.get("Usia")),
            "total_skor": _bersih(row.get("Total Skor")), "tingkat_kecanduan": _bersih(label),
            "waktu_pengisian": _bersih(row.get("Waktu Pengisian")) or datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    for tampil, db in zip(KOLOM_PERTANYAAN_TAMPIL, KOLOM_PERTANYAAN_DB): data[db] = _bersih(row.get(tampil))
    return data

def _baris_dari_format_db(row):
    d = {"Nama": row["nama"], "Kelas": row["kelas"], "Jenis Kelamin": row["jenis_kelamin"],
         "Usia": row["usia"], "Total Skor": row["total_skor"], "Tingkat_Kecanduan": row["tingkat_kecanduan"],
         "Waktu Pengisian": row["waktu_pengisian"]}
    for tampil, db in zip(KOLOM_PERTANYAAN_TAMPIL, KOLOM_PERTANYAAN_DB): d[tampil] = row[db]
    return d

def simpan_satu_jawaban(row):
    try:
        data = _baris_ke_format_db(row)
        kolom = list(data.keys()); vals = [data[k] for k in kolom]
        with _conn() as c:
            c.execute(f"INSERT INTO jawaban_kuesioner ({','.join(kolom)}) VALUES ({','.join(['?']*len(kolom))})", vals)
        _simpan_galat("")
        return True
    except Exception as e:
        _simpan_galat(f"Gagal menyimpan jawaban lokal: {e}")
        return False

def simpan_banyak_jawaban(df):
    berhasil = gagal = 0
    for row in df.to_dict("records"):
        if simpan_satu_jawaban(row): berhasil += 1
        else: gagal += 1
    return berhasil, gagal

def ambil_semua_jawaban():
    try:
        with _conn() as c: rows = c.execute("SELECT * FROM jawaban_kuesioner ORDER BY id ASC").fetchall()
        if not rows: return pd.DataFrame()
        df = pd.DataFrame([_baris_dari_format_db(dict(r)) for r in rows])
        df.insert(0, "No", range(1, len(df)+1))
        _simpan_galat("")
        return df
    except Exception as e:
        _simpan_galat(f"Gagal membaca penyimpanan lokal: {e}")
        return pd.DataFrame()
